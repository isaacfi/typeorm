#!/usr/bin/env node
import "reflect-metadata";
